<h2 align="center">Laporan Peminjaman Buku</h2>
<div class="content mt-3">
	<div class="card">
		<div class="card-body">
            <table border="1" cellspasing="0" cellpadding="5" width="100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Nama Buku</th>
                        <th>Tanggal Peminjaman</th>
                        <th>Tanggal Pengembalian</th>
                        <th>Status Peminjaman</th>                                                                         
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    include '../koneksi.php';
                    $no = 1;
                    $data = mysqli_query($koneksi,"SELECT * FROM  peminjaman INNER JOIN user ON peminjaman.UserID=user.UserID INNER JOIN buku ON peminjaman.BukuID=buku.BukuID");
                    while($d = mysqli_fetch_array($data)){
                        ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo $d['Username']; ?></td>
                            <td><?php echo $d['Judul']; ?></td>
                            <td><?php echo $d['TanggalPeminjaman']; ?></td>
                            <td><?php echo $d['TanggalPengembalian']; ?></td>
                            <td><?php echo $d['StatusPeminjaman']; ?></td>
                        </tr>
                    <?php }?>
                </tbody>
            </table>
            <script>
                window.print();
                settimeout(function() {
                    window.close();
                }, 100);
            </script>
        </div>
    </div>
</div>
